def main():
    listPres=findPres()
    num=int(input("Enter a number from 1 through 44: "))
    num2=int(input("Enter a number from 1 through 44: "))
    for x in range(num, num2):
        print(listPres[x-1])
        #print(listPres[num-1, num2-1], "was president number", num)
    
def findPres():
    infile=open("USPres.txt")
    listPres=[line.rstrip() for line in infile]
    infile.close()
    return listPres

main()