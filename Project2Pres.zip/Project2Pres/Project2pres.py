def main():
   preslist = []
   file="USPres.txt"
   infile = open(file, 'r')
   line = infile.readline()
   while line !="":
       preslist.append(line)
       line=infile.readline()
       #print(line)
   infile.close
   print ("Number of lines read", len(preslist))
   #for x in range(len(preslist)):
       #print( x+1,  preslist[x])
   findPres(preslist)
    
def findPres(findlist):
    start = int(input("Enter the lower number for the range"))
    end = int(input("Enter the higher number for the range"))
    print("\n\n  Presidents")
    for x in range(start-1, end, 1):
       print( "{0:5d} {1:<20s}".format(x+1,  findlist[x]) )         
            
main()